#!/usr/bin/env python
# coding: utf-8

# In[ ]:



def q1(str):
    word = 50 #to make the if statement run the first time
    idx = 0
    spaceIdx = 0
    #for size of the string
    size = 0
    for i in str:
        size+=1
    #loop to get the smallest word and its size
    while idx!=size:
        count=-1
        if str[idx] == ' ':
            for i in range(spaceIdx,idx):
                count+=1
            if count>1 and count<=word:
                word = count
                smallword=str[spaceIdx:idx]
            spaceIdx = idx
        idx+=1
        
    return word,smallword
        
str1 = input("Enter the stringe : ")
cntr,smallest = q1(str1)
print (smallest,cntr)        


# In[ ]:





# In[ ]:




