#!/usr/bin/env python
# coding: utf-8

# In[139]:


def frequency(str):
    #variables
    space = 1
    size=0
    k=0
    b=True#bool to use for a condition to run once
    idx=0
    cntr=0
    #size
    for i in str:
        size+=1
        if(i==' '):
            space+=1
    #arrays
    count_arr = [0]*space
    size_arr = [0]*space
    words_arr = ["0"]*space
    r=1
    #storing words in list and their counts in another array
    for i in range(size):
        if str[i]==' ':
            cntr=0
            words_arr[idx] = str[k:i]
            for j in range(k+1,i):
                cntr+=1
                if(i==0):
                    cntr+=1
            if(idx!=0):
                size_arr[idx] = cntr
            else:
                size_arr[idx] = cntr+1
            idx+=1
            k=i
        if i==size-1:
            cntr=0
            words_arr[idx] = str[k+1:i+1]
            for j in range(k+1,i+1):
                cntr+=1
            size_arr[idx] = cntr
            idx+=1
            k=i
    words_arr[0] = ' '+words_arr[0]
    
    #counting words if repeated
    for i in range(space):
        b=True
        for j in range(space):
            if words_arr[i] == words_arr[j]:
                count_arr[i]+=1
                if(b==False):
                    words_arr[j]="0"
                    count_arr[j]=0
                    size_arr[j]=0
                
    
    #removing repeated words
    m=0
    for i in range(space):
        if(count_arr[i]==1):
            m+=1
        if(count_arr[i]>1):
            j+=1
    s = int(space-(m-j))
    n_words_arr = ["0"]*s
    n_count_arr = [0]*s
    n_size_arr = [0]*s
    
    
    idx=0
    b=True
    for i in range(space):
        if count_arr[i]>=1 :
            n_words_arr[idx] = words_arr[i]
            n_count_arr[idx] = count_arr[i]
            n_size_arr[idx] = size_arr[i]
            idx+=1

    b=True
    #sorting in alpha numeric form
    for i in range(s):
        for j in range(s-1):
            if (n_words_arr[j] > n_words_arr[j+1] or ord(n_words_arr[j][0])>ord(n_words_arr[j+1][0])+32):
                temp = n_words_arr[j]
                temp2 = n_count_arr[j]
                temp3 = n_size_arr[j]
                n_words_arr[j] = n_words_arr[j+1]
                n_size_arr[j] = n_size_arr[j+1]
                n_count_arr[j] = n_count_arr[j+1]
                n_words_arr[j+1] = temp
                n_count_arr[j+1] = temp2
                n_size_arr[j+1] = temp3

     #printing the non repeating array
    for i in range(s):
        if(n_words_arr[i]!="0" and n_count_arr[i]!=0):
            if n_words_arr[i] != n_words_arr[i-1]:
                print(n_words_arr[i]," : ",n_count_arr[i])
                
str1 = "I love python but am confused am am whether I should choose python 2 or python3."
frequency(str1)


# In[ ]:





# In[ ]:





# In[ ]:




