#!/usr/bin/env python
# coding: utf-8

# In[5]:


def q2(str):
    digits=0
    alpha=0
    sentences=0
    spaces=0
    others=0
    words=1
    idx = 0
    #finding size of the string
    size=0
    for i in str:
        size+=1
    #while loop to calculate everything
    while idx!=size:
        if str[idx] == ' ':
            spaces+=1
        elif str[idx] == ' ' and str[idx-1] >= '0':
            words+=1
        elif str[idx] >= '0' and str[idx] <= '9':
            digits+=1
        elif str[idx] == '.':
            sentences+=1
            others+=1
        elif str[idx] >='A' and str[idx] <='z':
            alpha+=1
        else:
            others+=1
        if idx == size-1 and str[idx]!='.':
            sentences+=1
        idx+=1
        
    return words,digits,alpha,sentences,spaces,others

str1 = input("Enter the String : ")
w,d,a,sent,spac,o = q2(str1)
print ("Sentences: ",sent)
print ("Spaces: ",spac)
print ("Words: ",w)
print ("Digits: ",d)
print ("alphabets: ",a)
print ("Others: ",o)


# In[ ]:




