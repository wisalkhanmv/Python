#!/usr/bin/env python
# coding: utf-8

# In[57]:


def q4(l1,l2,l3,l4):
    common = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    elem=0
    print("Common Elements : ")
    for i in range(6):
        for j in range(6):
            if l1[i] == l2[j] or l1[i] == l3[j] or l1[i] == l4[j]:
                common[elem]=l1[i]
                for k in range(elem):
                    if common[k] == common[elem]:
                        common[elem]=0
                elem+=1
            if l2[i] == l3[j] or l2[i] == l4[j]:
                common[elem]=l2[i]
                for k in range(elem):
                    if common[k] == common[elem]:
                        common[elem]=0
                elem+=1
            if l3[i] == l4[j]:
                common[elem]=l3[i]
                for k in range(elem):
                    if common[k] == common[elem]:
                        common[elem]=0
                elem+=1
    for j in common:
        if j !=0:
            print(j)
list1 = [1, 3, 5, 7, 9, 11]
list2 = [5, 8, 14, 17, 18, 19]
list3 = [9, 7, 12, 13, 15,0]
list4 = [4, 9, 11, 13, 17,0]

q4(list1,list2,list3,list4)


#  

# In[31]:





# In[ ]:




