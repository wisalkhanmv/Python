#!/usr/bin/env python
# coding: utf-8

# In[16]:


def q3(str):
    size = 0
    k=0
    cntr=0
    space = 0
    for i in str:
        size+=1
        if i == ' ':
            space+=1
    array = [0,0,0,0,0,0,0]
    idx=0
    while idx!=size:
        cntr=-1
        if str[idx]==' ' or idx==size-1:
            for i in range(k,idx):
                cntr+=1
            if(idx == size-1):
                cntr+=1
            if cntr < 6:
                array[cntr] += 1
            else:
                array[6] += 1
            k=idx+1
        idx+=1
    return array

arr = input("Enter string :  ")
arrayofcounts = q3(arr)
print("The string contains ")
if arrayofcounts[0] > 0:
    print(arrayofcounts[0],"one-letter")          
if arrayofcounts[1] > 0:
    print(arrayofcounts[1],"two-letter")
if arrayofcounts[2] > 0:
    print(arrayofcounts[2],"three-letter")
if arrayofcounts[3] > 0:
    print(arrayofcounts[3],"four-letter")
if arrayofcounts[4] > 0:
    print(arrayofcounts[4],"five-letter")
if arrayofcounts[5] > 0:
    print(arrayofcounts[5],"six-letter")
if arrayofcounts[6] > 0:
    print(arrayofcounts[6],"more-than-six-letter")
print("words")


# In[ ]:





# In[ ]:




