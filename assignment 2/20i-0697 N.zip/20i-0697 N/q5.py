#!/usr/bin/env python
# coding: utf-8

# In[3]:


def dict(d1,d2):
    array=[0,0,0,0]
    idx=0
    for k in d1.keys():
        array[idx] = k
        idx+=1
    for j in range(3):
            if d1[array[j]] == d2[array[j]]:
                print(array[j],d1[array[j]])
    print("is present in both dictionaries d1 and d2")

dict1 = {'k1': 1, 'k2': 3, 'k3': 2, 'k4':3}
dict2 = {'k1': 1, 'k2': 2, 'k3': 2}
dict(dict1,dict2)


# In[ ]:




