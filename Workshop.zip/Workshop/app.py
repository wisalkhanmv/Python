from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/workshop/')
def workshop():
    return "<h1>Welcome to this Workshop!</h1>"

import pandas as pd
import numpy as np

df=pd.read_table('SMSSpamCollection.txt',sep='\t',header=None,names=['label', 
'sms_message'])

df['label'] = df.label.map({'ham':0, 'spam':1})

from sklearn.feature_extraction.text import CountVectorizer
count_vector = CountVectorizer()
featureVector=count_vector.fit_transform(df['sms_message'].values)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(featureVector,df['label'],random_state=1)

from sklearn.naive_bayes import MultinomialNB

naive_bayes = MultinomialNB()
naive_bayes.fit(X_train, y_train)

reverse_map = {0: 'ham', 1: 'spam'}



@app.route('/results/', methods=['GET', 'POST'])
def results():
    if request.method == 'POST':
        text = request.form['text']
        vector = count_vector.transform( [text] )
        label = naive_bayes.predict(vector)
        message = reverse_map[label[0]]
        return render_template('results.html', message=message)
    else:
        return redirect(url_for('index'))


@app.errorhandler(404)
def not_found(error):
    return "<h1>404</h1>"