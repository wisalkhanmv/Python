import pandas as pd
import numpy as np

df=pd.read_table('SMSSpamCollection.txt',sep='\t',header=None,names=['label', 
'sms_message'])

df['label'] = df.label.map({'ham':0, 'spam':1})

from sklearn.feature_extraction.text import CountVectorizer
count_vector = CountVectorizer()
featureVector=count_vector.fit_transform(df['sms_message'].values)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(featureVector,df['label'],random_state=1)

from sklearn.naive_bayes import MultinomialNB

naive_bayes = MultinomialNB()
naive_bayes.fit(X_train, y_train)

reverse_map = {0: 'ham', 1: 'spam'}


vector = count_vector.transform( ['This is a telemarketer message offer.'] )
label = naive_bayes.predict(vector)

print(reverse_map[label[0]])